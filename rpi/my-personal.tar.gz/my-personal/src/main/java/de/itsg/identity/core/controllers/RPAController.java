package de.itsg.identity.core.controllers;

import de.itsg.identity.common.model.rpa.RPAUserDataModel;
import de.itsg.identity.common.model.rpa.RpaAttributeAccessManagement;
import de.itsg.identity.common.services.RpaManagementServices;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Created by Rahul Bhandwalkar on 6/1/2016.
 */

@RestController
@RequestMapping("rpa")
@Slf4j
public class RPAController {

    @Autowired
    RpaManagementServices services;


    @RequestMapping(value = "/byUserIdAndSpid/{uuid}/{spid}", method = RequestMethod.GET)
    public Iterable<RPAUserDataModel> getAllRPAByUserIdAndSPID(@PathVariable String uuid, @PathVariable Long spid){
        return services.findAllRPAByUserAndSp(uuid,spid);
    }

    @RequestMapping(value = "/isRPAConfirmed/{uuid}/{spid}", method = RequestMethod.GET)
    public Boolean isRPASinged(@PathVariable String uuid, @PathVariable Long spid){
        return services.isRPASigned(uuid,spid);
    }

    @RequestMapping(value = "/byUserIdAndmoduleName/{uuid}/{moduleName}", method = RequestMethod.GET)
    public Iterable<RpaAttributeAccessManagement> getAllRPAByUserIdAndModuleName(@PathVariable String uuid, @PathVariable String moduleName){
        return services.findAllRPAByUserAndModule(uuid,moduleName);
    }

    @RequestMapping(value = "/{uuid}", method = RequestMethod.GET)
    public Iterable<RpaAttributeAccessManagement> getAllRPAByUserId(@PathVariable String uuid){
        return services.findAllRPAByUserId(uuid);
    }

    @RequestMapping(value = "/{uuid}/{spid}", method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.CREATED)
    public Iterable<RpaAttributeAccessManagement> save(@PathVariable String uuid, @PathVariable Long spid, @Validated({RpaAttributeAccessManagement.Create.class}) @RequestBody List<RpaAttributeAccessManagement> list) {
        log.debug("Adding RPA for the User {} ", uuid);
        for(RpaAttributeAccessManagement rpa:list){
            if(rpa.getIdentity()!=uuid || rpa.getServiceProviderId()!=spid){
                throw new IllegalArgumentException("User Id and Service Provider Id mismatch");
            }
        }
        return services.create(list);
    }

    @RequestMapping(value = "/{uuid}/{spid}", method = RequestMethod.PUT)
    public Iterable<RpaAttributeAccessManagement> update(@PathVariable String uuid, @PathVariable Long spid, @Validated(RpaAttributeAccessManagement.class) @RequestBody List<RpaAttributeAccessManagement> list) {
        log.debug("Saving RPA for the User {} and service Provider {}", uuid, spid);
        for(RpaAttributeAccessManagement rpa:list){
            if(rpa.getIdentity()!=uuid || rpa.getServiceProviderId()!=spid){
                throw new IllegalArgumentException("User Id and Service Provider Id mismatch");
            }
        }
        return services.update(list);
    }


    @RequestMapping(value = "confirm/{uuid}/{spid}", method = RequestMethod.PUT)
    public void confirm(@PathVariable String uuid, @PathVariable Long spid) {
        log.debug("Confirming RPA for the User {} and service Provider {}", uuid, spid);
        services.confirmRPAByUserAndSP(uuid, spid);
    }

    @RequestMapping(value = "/{uuid}/{spid}", method = RequestMethod.DELETE)
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable String uuid, @PathVariable Long spid, @Validated(RpaAttributeAccessManagement.class) @RequestBody List<RpaAttributeAccessManagement> list) {
        log.debug("Saving RPA for the User {} and service Provider {}", uuid, spid);
        for(RpaAttributeAccessManagement rpa:list){
            if(rpa.getIdentity()!=uuid || rpa.getServiceProviderId()!=spid){
                throw new IllegalArgumentException("User Id and Service Provider Id mismatch");
            }
        }
         services.delete(list);
    }

    @RequestMapping(value = "/{uuid}/{ModuleName}", method = RequestMethod.DELETE)
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteByModuleName(@PathVariable String uuid, @PathVariable String ModuleName) {
        log.debug("Saving RPA for the User {} and Module {}", uuid, ModuleName);
        services.deleteByUserIdAndModuleName(uuid,ModuleName);
    }
}
