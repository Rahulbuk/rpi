package de.itsg.identity.core.services.impl;

import de.itsg.identity.common.model.rpa.RPAUserDataModel;
import de.itsg.identity.common.model.rpa.RpaAttributeAccessManagement;
import de.itsg.identity.common.services.RpaManagementServices;
import de.itsg.identity.common.model.rpa.RPARepository;
import de.itsg.ra.common.model.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestOperations;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Rahul Bhandwalkar on 6/1/2016.
 */
@Service
@Transactional
@Slf4j
public class RpaManagementServicesImpl implements RpaManagementServices {

    @Autowired
    RPARepository repository;

    @Autowired
    @Qualifier("IdentityAPIRESTTemplate")
    private RestOperations restOperations;

    @Value("${itsg-ra.url}")
    private String raApiUrl;

    private static final String SP_BY_MODULE = "/service-providers/findByRAModule/{moduleName}";

    private static final String ATTRIBUTE_ASSIGNMENTS = "/service-providers/assignments/{id}";
    @Override
    public Iterable<RpaAttributeAccessManagement> findAllRPAByUserId(String uuid) {
        return repository.findAllRPAByUser(uuid);
    }

    @Override
    public Iterable<RpaAttributeAccessManagement> findAllRPAByUserAndModule(String id, String moduleName) {
        return repository.findAllRPAByUserAndModule(id,moduleName);
    }

    @Override
    public Iterable<RPAUserDataModel> findAllRPAByUserAndSp(String uuid, Long serviceProviderId) {

        Iterable<RpaAttributeAccessManagement> assignments =repository.findAllRPAByUserAndSp(uuid,serviceProviderId);
        ParameterizedTypeReference<Iterable<ServiceProviderQualityLevelAttributeMapping>> responseType =
                new ParameterizedTypeReference<Iterable<ServiceProviderQualityLevelAttributeMapping>>() {};
        Iterable<ServiceProviderQualityLevelAttributeMapping> mappings =
                restOperations.exchange(raApiUrl + ATTRIBUTE_ASSIGNMENTS,  HttpMethod.GET, null, responseType, serviceProviderId).getBody();
        List<RPAUserDataModel> rpaUserDataModel = new ArrayList<>();
        for(RpaAttributeAccessManagement assignment:assignments){
            if(assignment.getAgreed()){
                continue;
            }
            RPAUserDataModel model = new RPAUserDataModel();
            List<AttributeDefinition> attributeDefinitions = new ArrayList<>();
            for(ServiceProviderQualityLevelAttributeMapping mapping:mappings){

                if(mapping.getServiceProviderQualityLevelRegistration().getQualityLevel().getRaModule().getName().equalsIgnoreCase(assignment.getModuleName())){
                    attributeDefinitions.add(mapping.getAttributeDefinition());
                }
            }
            assignment.setModuleType(ModuleType.RA);
            model.setRpaAttributeAccessManagement(assignment);
            model.setAttributeDefinitions(attributeDefinitions);
            rpaUserDataModel.add(model);

        }

        return rpaUserDataModel;
    }

    @Override
    public void delete(RpaAttributeAccessManagement rpaAttributeAccessManagement) {
        repository.delete(rpaAttributeAccessManagement);
    }

    @Override
    public void delete(List<RpaAttributeAccessManagement> list) {
        repository.delete(list);
    }

    @Override
    public void deleteByModuleName(String moduleName) {
        repository.deleteByModuleName(moduleName);

    }

    @Override
    public void deleteByUserId(String uuid) {
        repository.deleteByUserId(uuid);
    }

    @Override
    public void deleteBySpId(Long serviceProviderId) {
        repository.deleteBySpId(serviceProviderId);
    }

    @Override
    public void deleteByUserIDAndSpId(String uuid, Long serviceProviderId) {
        repository.deleteByUserIDAndSpId(uuid,serviceProviderId);
    }

    @Override
    public void confirmRPAByUserAndSP(String uuid, Long serviceProviderId) {
       Iterable<RpaAttributeAccessManagement> lsit= repository.findAllRPAByUserAndSp(uuid, serviceProviderId);
        for(RpaAttributeAccessManagement mgt : lsit){
            mgt.setAgreed(true);
        }
        repository.save(lsit);
    }

    @Override
    public void deleteByUserIdAndModuleName(String uuid, String moduleName) {
        repository.deleteByUserIdAndModuleName(uuid,moduleName);
    }

    @Override
    public void create(RaModule module, String uuid) {
        ParameterizedTypeReference<Iterable<ServiceProvider>> responseType = new ParameterizedTypeReference<Iterable<ServiceProvider>>() {
        };
        Iterable<ServiceProvider> spList = restOperations.exchange(raApiUrl + SP_BY_MODULE,  HttpMethod.GET, null, responseType, module.getName()).getBody();
        List<RpaAttributeAccessManagement>  rpaAttributeAccessManagementList = new ArrayList<>();
        for(ServiceProvider sp:spList){
            RpaAttributeAccessManagement rpaAttributeAccessManagement = new RpaAttributeAccessManagement();
            rpaAttributeAccessManagement.setIdentity(uuid);
            rpaAttributeAccessManagement.setAgreed(Boolean.FALSE);
            rpaAttributeAccessManagement.setModuleName(module.getName());
            rpaAttributeAccessManagement.setServiceProviderId(sp.getId());
            rpaAttributeAccessManagement.setModuleType(module.getModuleType());
            rpaAttributeAccessManagementList.add(rpaAttributeAccessManagement);
        }
        this.create(rpaAttributeAccessManagementList);
    }


    @Override
    public RpaAttributeAccessManagement create(RpaAttributeAccessManagement rpaAttributeAccessManagement) {
           return repository.save(rpaAttributeAccessManagement);
    }

    @Override
    public Iterable<RpaAttributeAccessManagement> create(List<RpaAttributeAccessManagement> rpaAttributeAccessManagements) {
         return repository.save(rpaAttributeAccessManagements);
    }

    @Override
    public RpaAttributeAccessManagement update(RpaAttributeAccessManagement rpaAttributeAccessManagement) {
        return repository.save(rpaAttributeAccessManagement);
    }

    @Override
    public Iterable<RpaAttributeAccessManagement> update(List<RpaAttributeAccessManagement> rpaAttributeAccessManagements) {
        return repository.save(rpaAttributeAccessManagements);
    }

    @Override
    public Boolean isRPASigned(String uuid, Long spid) {
            for(RpaAttributeAccessManagement rpa : repository.findAllRPAByUserAndSp(uuid,spid)){
                if(!rpa.getAgreed()){
                    return Boolean.FALSE;
                }
            }

        return Boolean.TRUE;
    }
}
