package de.itsg.identity.core.repositories.impl;

import de.itsg.identity.common.model.GenericModuleUser;
import de.itsg.identity.common.repositories.GenericModuleRepository;
import de.itsg.identity.core.repositories.rowmappers.GenericModuleRowMapper;
import de.itsg.ra.common.model.AttributeDefinition;
import de.itsg.ra.common.model.AttributeType;
import de.itsg.ra.common.model.RaModule;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcOperations;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Created by nstanar on 18/01/16.
 */
@Repository
@Slf4j
public class GenericModuleRepositoryImpl implements GenericModuleRepository {

    private static final String FIND_ALL_USERS_QUERY_TEMPLATE = "SELECT * FROM %s";

    private static final String FIND_USER_QUERY_TEMPLATE = "SELECT * FROM %s WHERE IDENTITY_UUID = ?";

    private static final String DELETE_USER_QUERY_TEMPLATE = "DELETE FROM %s WHERE IDENTITY_UUID = ?";

    private static final String DELETE_MODULE_TEMPLATE = "DROP TABLE %s";

    private static final String INSERT_USER_MODULE_MAP = "INSERT INTO USER_MODULE_MAP (identity_uuid,module_name) VALUES (?,?)";

    private static final String SELECT_USER_MODULE_MAP = "SELECT module_name FROM USER_MODULE_MAP WHERE identity_uuid =?";

    @Autowired
    private JdbcOperations jdbcOperations;

    @Override
    public GenericModuleUser findUser(RaModule raModule, String identityUuid) {
        String findUserQuery = String.format(FIND_USER_QUERY_TEMPLATE, raModule.getName());
        log.debug("Executing find user query: {}", findUserQuery);
        return jdbcOperations.queryForObject(findUserQuery, new GenericModuleRowMapper(raModule.getAttributeDefinitions()), identityUuid);
    }

    @Override
    public Iterable<GenericModuleUser> findAllUsers(RaModule raModuleDetails) {
        String findAllUsersQuery = String.format(FIND_ALL_USERS_QUERY_TEMPLATE, raModuleDetails.getName());
        log.debug("Executing find all users query: {}", findAllUsersQuery);
        List<GenericModuleUser> genericModules = jdbcOperations.query(findAllUsersQuery, new GenericModuleRowMapper(raModuleDetails.getAttributeDefinitions()));
        return genericModules;
    }

    @Override
    public Iterable<String> findAllUsersModuleList(String uuid) {

        log.debug("Executing find all users query: {}", SELECT_USER_MODULE_MAP);
        List<String> moduleList = jdbcOperations.queryForList(SELECT_USER_MODULE_MAP,String.class,uuid);
        return moduleList;
    }

    @Override
    public Iterable<GenericModuleUser> findAllUserModules(Long genericModuleUser) {
        jdbcOperations.queryForList("select i.*,flo.* from IDENTITY as i inner JOIN ra_flo as flo on i.uuid=flo.identity_uuid where i.uuid=?");

        return null;
    }

    @Override
    public void deleteUser(String moduleName, String identityUuid) {
        String deleteUserStatement = String.format(DELETE_USER_QUERY_TEMPLATE, moduleName);
        log.debug("Executing delete user statement: {}", deleteUserStatement);
        jdbcOperations.update(deleteUserStatement, identityUuid);
    }

    @Override
    public GenericModuleUser updateUser(RaModule raModule, GenericModuleUser genericModuleUser) {
        Map<String, Object> qaAttributeSet = genericModuleUser.getQaAttributeSet();

        StringBuilder updateStatementBuilder = new StringBuilder("UPDATE ").
                append(raModule.getName()).
                append(" SET ");

        for (String attributeName : qaAttributeSet.keySet()) {
            updateStatementBuilder.append(attributeName).append(" = ?, ");
        }

        /** delete unnecessary space and comma from the end of String */
        updateStatementBuilder.setLength(updateStatementBuilder.length() - 2);
        updateStatementBuilder.append(" WHERE IDENTITY_UUID = ?");


        List<Object> sqlParameters = new ArrayList<>(qaAttributeSet.values());
        sqlParameters.add(genericModuleUser.getUuid());

        String updateStatement = updateStatementBuilder.toString();
        log.debug("Executing update user statement: {}", updateStatement);

        jdbcOperations.update(updateStatement, sqlParameters.toArray());

        String insertUserModuleMap="";
        return findUser(raModule, genericModuleUser.getUuid());
    }

    @Override
    public GenericModuleUser saveUser(RaModule raModule, GenericModuleUser genericModuleUser) {
        Map<String, Object> qaAttributeSet = genericModuleUser.getQaAttributeSet();

        StringBuilder insertStatementBuilder = new StringBuilder("INSERT INTO ").
                append(raModule.getName()).
                append(" (");


        for (String attributeName : qaAttributeSet.keySet()) {
            insertStatementBuilder.append(attributeName).append(",");
        }

        insertStatementBuilder.append("identity_uuid) VALUES (");

        for (int i = 0; i < qaAttributeSet.keySet().size() + 1; i++) {
            insertStatementBuilder.append("?,");
        }

        /** delete unnecessary comma from the end of String */
        insertStatementBuilder.setLength(insertStatementBuilder.length() - 1);
        insertStatementBuilder.append(")");

        List<Object> sqlParameters = new ArrayList<>(qaAttributeSet.values());
        sqlParameters.add(genericModuleUser.getUuid());

        String updateStatement = insertStatementBuilder.toString();
        log.debug("Executing insert user statement: {}", updateStatement);

        jdbcOperations.update(updateStatement, sqlParameters.toArray());

        log.debug("Executing insert user module map statement: {}", updateStatement);

        jdbcOperations.update(INSERT_USER_MODULE_MAP,genericModuleUser.getUuid(),raModule.getName().toLowerCase());

        return findUser(raModule, genericModuleUser.getUuid());
    }

    @Override
    public void delete(String moduleName) {
        String deleteModuleStatement = String.format(DELETE_MODULE_TEMPLATE, moduleName);
        log.debug("Executing delete ra module statement: {}", deleteModuleStatement);
        jdbcOperations.execute(deleteModuleStatement);
    }

    @Override
    public void create(RaModule raModule) {
        String createModuleStatement = retrieveCreateModuleSql(raModule);
        log.debug("Executing create ra module statement: {}", createModuleStatement);
        jdbcOperations.execute(createModuleStatement);
    }

    @Override
    public void alter(String moduleName, List<AttributeDefinition> attributeDefinitions) {
        String alterModuleStatement = retrieveAlterModuleSql(moduleName, attributeDefinitions);
        log.debug("Executing alter ra module statement: {}", alterModuleStatement);
        jdbcOperations.execute(alterModuleStatement);
    }

    private String retrieveAlterModuleSql(String moduleName, List<AttributeDefinition> attributeDefinitions) {

        StringBuilder stringBuilder = new StringBuilder("ALTER TABLE ").
                append(moduleName).
                append(" ");

        for (String columnDefinition : generateColumnsSql(attributeDefinitions)) {
            stringBuilder.append("ADD ").append(columnDefinition);
        }

        /** delete unnecessary comma from the end of String */
        stringBuilder.setLength(stringBuilder.length() - 1);

        return stringBuilder.toString();
    }

    private String retrieveCreateModuleSql(RaModule raModule) {

        StringBuilder stringBuilder = new StringBuilder("CREATE TABLE ").append(raModule.getName()).
                append(" (id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,");

        for (String columnDefinition : generateColumnsSql(raModule.getAttributeDefinitions())) {
            stringBuilder.append(columnDefinition);
        }

        stringBuilder.append("identity_uuid VARCHAR(40) NOT NULL,\n" +
                "  FOREIGN KEY (identity_uuid) REFERENCES IDENTITY (uuid)\n" +
                "  ON DELETE CASCADE\n" +
                "  ON UPDATE CASCADE\n" +
                ")  ENGINE=InnoDB DEFAULT CHARSET=utf8;");

        return stringBuilder.toString();
    }

    private List<String> generateColumnsSql(List<AttributeDefinition> attributeDefinitions) {
        List<String> columnDefinitions = new ArrayList<>();
        StringBuilder stringBuilder = new StringBuilder();

        for (AttributeDefinition attributeDefinition : attributeDefinitions) {
            stringBuilder.append(attributeDefinition.getName()).append(" ").append(attributeDefinition.getType()).append(" ");
            if (attributeDefinition.getType() == AttributeType.VARCHAR) {
                stringBuilder.append("(255) ");
            }
            if (attributeDefinition.getUnique()) {
                stringBuilder.append("UNIQUE ");
            }
            if (!attributeDefinition.getOptional()) {
                stringBuilder.append("NOT NULL");
            }
            stringBuilder.append(",");
            columnDefinitions.add(stringBuilder.toString());
            stringBuilder.setLength(0);
        }
        return columnDefinitions;
    }
}
