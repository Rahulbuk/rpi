package de.itsg.identity.core.messaging;

import de.itsg.identity.common.model.DoubleOptInStatus;
import de.itsg.identity.common.model.GenericModuleUser;
import de.itsg.identity.common.model.Identity;
import de.itsg.identity.common.model.Status;
import de.itsg.identity.common.services.BasicModuleService;
import de.itsg.identity.common.services.DoubleOptInService;
import de.itsg.identity.common.services.GenericModuleService;
import de.itsg.messaging.configuration.RabbitMQConfiguration;
import de.itsg.messaging.message.StateChangeMessage;
import de.itsg.messaging.receiver.ITSGMsgReceiver;
import de.itsg.messaging.sender.ITSGMsgSender;
import lombok.extern.slf4j.Slf4j;
import org.springframework.amqp.rabbit.annotation.Exchange;
import org.springframework.amqp.rabbit.annotation.Queue;
import org.springframework.amqp.rabbit.annotation.QueueBinding;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Iterator;

/**
 * Created by Rahul Bhandwalkar on 3/26/2016.
 */

@Component
@Slf4j

public class IdentityMessageReceiver extends ITSGMsgReceiver
{

    @Autowired
    BasicModuleService basicModuleService;
    @Autowired
    DoubleOptInService doubleOptInService;

    public IdentityMessageReceiver() {
        super();
    }

        @RabbitListener(bindings = @QueueBinding(
        value = @Queue(value = "de.itsg.identity", durable = "true"),
        exchange = @Exchange(value = RabbitMQConfiguration.exchangeName, type = "fanout", durable = "true")))
    @Override
    public void processMessage(StateChangeMessage msg) {
        log.debug("-----------------MessageReceived------------ ::=> "+msg.toString());

        if(msg.getModuleName().equalsIgnoreCase("BASIC_MODULE")){
            Identity identity =(Identity) msg.getIdentity();
            if(msg.getModuleStatus().equals(Status.COMMITTED.name())&& msg.getDoubleOptInStatus().
                    equals(DoubleOptInStatus.EMAIL_NOT_SENT.name())){
                        doubleOptInService.sendEmail(identity);
            } else if(msg.getModuleStatus().equals(Status.COMMITTED.name())&& msg.getDoubleOptInStatus().
                    equals(DoubleOptInStatus.EMAIL_SENT.name())){
                        identity.setDoubleOptInStatus(DoubleOptInStatus.EMAIL_SENT);
                        identity.setStatus(Status.PREREQUISITES_FULFILLED);
                        basicModuleService.save(identity);
            }else if(msg.getModuleStatus().equals(Status.PREREQUISITES_FULFILLED.name())&& msg.getDoubleOptInStatus().
                    equals(DoubleOptInStatus.EMAIL_CONFIRMED.name())){
                        identity.setStatus(Status.APPROVED);
                        basicModuleService.save(identity);
            } else if(msg.getDoubleOptInStatus().equals(DoubleOptInStatus.EMAIL_CONFIRMED.name())
                    && Status.APPROVED.name().equals(msg.getModuleStatus())){
            }
        } else {
            log.debug("Message Not intended for Basic Module ");
        }
    }
}
