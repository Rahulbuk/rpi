package de.itsg.identity.core.services.impl;

import de.itsg.identity.common.model.DoubleOptIn;
import de.itsg.identity.common.model.EmailConfirmStatus;
import de.itsg.identity.common.model.Identity;
import de.itsg.identity.common.repositories.DoubleOptInRepository;
import de.itsg.identity.common.services.BasicModuleService;
import de.itsg.identity.common.services.DoubleOptInService;
import de.itsg.messaging.message.DoubleOptInMessage;
import de.itsg.messaging.sender.DoubleOptInMessageSender;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Date;
import java.util.UUID;

/**
 * Created by Rahul Bhandwalkar on 3/29/2016.
 */
@Service
@Transactional
@Slf4j
public class DoubleOptInServiceIml implements DoubleOptInService {

    @Autowired
    BasicModuleService basicModuleService;
    @Autowired
    DoubleOptInRepository repository;

    @Autowired
    DoubleOptInMessageSender sender;

    @Autowired
    Environment env;
    @Override
    public void sendEmail(Identity identity) {

        DoubleOptIn doubleOptIn = new DoubleOptIn();
        doubleOptIn.setIdentity(identity);
        doubleOptIn.setToken(generateToken(identity));
        doubleOptIn =repository.save(doubleOptIn);
        SimpleDateFormat sdf = new SimpleDateFormat("MMM dd,yyyy HH:mm");
        Date expiryData = new Date(doubleOptIn.getCreateTime()+getTokenValidity()*60*60*1000);
        System.out.println(sdf.format(expiryData));
        DoubleOptInMessage message = new DoubleOptInMessage(identity.getEmail(), identity.getUuid(), doubleOptIn.getToken());
        message.setFirstname(identity.getFirstname());
        message.setLastname(identity.getLastname());
        message.setNickname(identity.getNickname());
        sender.send(message);

    }

    @Override
    public EmailConfirmStatus confirmEmail(String uuid, String token) {
        DoubleOptIn doi = repository.findByUUID(uuid);
        EmailConfirmStatus retvalue= EmailConfirmStatus.INITIATED;
        if(!doi.getStatus().equals(retvalue)){
            if(doi.getStatus().equals(EmailConfirmStatus.SUCCESSFUL)){
                return EmailConfirmStatus.ALREADY_ACTIVATED;
            }else {
            return doi.getStatus();
            }
        }
        int tokenValidity= getTokenValidity();
        if(StringUtils.isEmpty(token)||(! doi.getToken().equals(token)))
            retvalue = EmailConfirmStatus.INVALID_TOKEN;
        if(System.currentTimeMillis()>(doi.getCreateTime()+tokenValidity*60*60*1000)){
            retvalue =EmailConfirmStatus.EXPIRED;
        }  else {
            retvalue =EmailConfirmStatus.SUCCESSFUL;
        }
        try {
            doi.setStatus(retvalue);
            repository.save(doi);
        } catch (Exception e){
            log.error(e.getMessage());
            retvalue = EmailConfirmStatus.ERRORED;
        }
        return retvalue;
    }

    private String generateToken(Identity identity){
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(identity.getUuid());
        stringBuilder.append(identity.getEmail());
        stringBuilder.append(identity.getFirstname());
        stringBuilder.append(identity.getLastname());
        stringBuilder.append(UUID.randomUUID().toString());
       return new String(  Base64.getEncoder().encode(stringBuilder.toString().getBytes()));
       }


    private int getTokenValidity(){
        int tokenValidity=48;
        String tokenValidityString = env.getProperty("itsg-token-validity");
        if(!StringUtils.isEmpty(tokenValidityString)){
            try {
                tokenValidity = Integer.parseInt(tokenValidityString);
            }catch (NumberFormatException ife){
                log.error("Invalid token validity. Defaulting to "+ tokenValidity +" Hours");
            }
        }
        return tokenValidity;
    }

}
