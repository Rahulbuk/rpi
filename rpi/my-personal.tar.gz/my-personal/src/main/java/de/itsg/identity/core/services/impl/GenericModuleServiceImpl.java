package de.itsg.identity.core.services.impl;

import de.itsg.identity.common.repositories.GenericModuleRepository;
import de.itsg.identity.common.model.GenericModuleUser;
import de.itsg.identity.common.services.GenericModuleService;
import de.itsg.identity.common.services.RpaManagementServices;
import de.itsg.identity.core.repositories.impl.GenericModuleRepositoryUserStoreImpl;
import de.itsg.ra.common.model.AttributeDefinition;
import de.itsg.ra.common.model.RaModule;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestOperations;
import org.wso2.carbon.user.api.UserStoreException;

import java.util.List;


/**
 * Created by nstanar on 18/01/16.
 */
@Service
@Transactional
@Slf4j
public class GenericModuleServiceImpl implements GenericModuleService {

    @Value("${itsg-ra.modules.url}")
    private String raApiModulesUrl;

    @Autowired
    private GenericModuleRepository genericModuleRepository;

    @Autowired
    @Qualifier("IdentityAPIRESTTemplate")
    private RestOperations restOperations;

    @Autowired
    private RpaManagementServices rpaManagementServices;

    @Autowired
    private MessageSource messageSource;

    @Autowired
    private GenericModuleRepositoryUserStoreImpl userStrore;

    @Override
    @Transactional(readOnly = true)
    public Iterable<GenericModuleUser> findAllUsers(String moduleName) {
        log.debug("Retrieving data for all users registered for module {}", moduleName);
        return userStrore.findAllUsers(getModuleDetails(moduleName).getBody());
    }

    @Override
    public void deleteUser(String moduleName, String identityUuid) {
        log.debug("Deleting data from module {} for user with uuid {}", identityUuid);
        userStrore.deleteUser(moduleName, identityUuid);
    }

    @Override
    public GenericModuleUser updateUser(String moduleName, GenericModuleUser genericModuleUser) {
        log.debug("Updating data for user with uuid {} in module {}", genericModuleUser.getUuid(), moduleName);
        return userStrore.updateUser(getModuleDetails(moduleName).getBody(), genericModuleUser);
    }

    @Override
    public GenericModuleUser saveUser(String moduleName, GenericModuleUser genericModuleUser) {
        log.debug("Creating data for user with uuid {} in module {}", genericModuleUser.getUuid(), moduleName);
        GenericModuleUser savedGenericModuleUser = null;
        try {
            RaModule module = getModuleDetails(moduleName).getBody();
            savedGenericModuleUser = userStrore.saveGenericUser(module,genericModuleUser);
          rpaManagementServices.create(module, genericModuleUser.getUuid());
        } catch (UserStoreException e) {
            e.printStackTrace();
        }
        savedGenericModuleUser.setMessage(messageSource.getMessage("uuid.generated", null, LocaleContextHolder.getLocale()));
        return savedGenericModuleUser;
    }

    @Override
    public void delete(String moduleName) {
        log.debug("Deleting module {}", moduleName);
        //Physical deletion. This is in requirement.
        genericModuleRepository.delete(moduleName);
    }

    @Override
    public void create(RaModule raModule) {
        log.debug("Creating module {}", raModule.getName());
        genericModuleRepository.create(raModule);
    }

    @Override
    public void alter(String moduleName, List<AttributeDefinition> attributeDefinitions) {
        log.debug("Altering module {}", moduleName);
        genericModuleRepository.alter(moduleName, attributeDefinitions);
    }

    @Override
    @Transactional(readOnly = true)
    public GenericModuleUser findUser(String moduleName, String identityUuid) {
        log.debug("Retrieving data for user with uuid {} registered for module {}", identityUuid, moduleName);
        return userStrore.findUser(getModuleDetails(moduleName).getBody(), identityUuid);
    }

    private ResponseEntity<RaModule> getModuleDetails(String moduleName) {
        return restOperations.exchange(raApiModulesUrl + "/name/{name}", HttpMethod.GET, null, RaModule.class, moduleName);
    }

    @Override
    public Iterable<String> findAllUsersModuleList(String identityUuid){

        log.debug("Getting module list for the user {}", identityUuid);
        return  userStrore.findAllUsersModuleList(identityUuid);
    }

}
