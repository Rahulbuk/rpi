package de.itsg.identity.core.controllers;

import com.fasterxml.jackson.annotation.JsonView;
import de.itsg.identity.common.model.Identity;
import de.itsg.identity.common.services.BasicModuleService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

/**
 * Created by nstanar on 28/12/15.
 */
@RestController
@RequestMapping("basic-module/users")
@Slf4j

public class BasicModuleController {

    @Autowired
    private BasicModuleService basicModuleService;

    @Autowired
    private MessageSource messageSource;

    @RequestMapping(method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.CREATED)
    @JsonView(Identity.Insert.class)
    public Identity save(@Validated({Identity.Insert.class}) @RequestBody Identity identity) {
        log.debug("Creating identity (basic module data) with email {} ", identity.getEmail());
        return basicModuleService.save(identity);
    }

    @RequestMapping(value = "/{uuid}", method = RequestMethod.GET)
    public Identity findOne(@PathVariable String uuid) {
        log.debug("Retrieving identity (basic module data) with uuid {} ", uuid);
        return basicModuleService.findOne(uuid);
    }


    @RequestMapping(value = "/email", method = RequestMethod.GET)
    public Identity findByEmail(@RequestParam (value = "email" , required = true) String email) {
        log.debug("Retrieving identity (basic module data) with uuid {} ", email);
        return basicModuleService.findByEmail(email);
    }

    @RequestMapping(method = RequestMethod.GET)
    public Iterable<Identity> findAll() {
        log.debug("Retrieving all identities (basic module data for all users).");
        return basicModuleService.findAll();
    }

    @RequestMapping(value = "/{uuid}", method = RequestMethod.PUT)
    public Identity update(@PathVariable String uuid, @RequestBody @Validated({Identity.Update.class}) Identity identity) {
        log.debug("Updating identity (basic module data) with uuid {} ", uuid);
        if (!uuid.equals(identity.getUuid())) {
            throw new IllegalArgumentException(messageSource.getMessage("path.param.not.matching.request.entity", null, LocaleContextHolder.getLocale()));
        }
        return basicModuleService.update(identity);
    }

    @RequestMapping(value = "/{uuid}", method = RequestMethod.DELETE)
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable String uuid) {
        log.debug("Deleting identity (basic module data) with uuid {} ", uuid);
        basicModuleService.delete(uuid);
    }
}
