package de.itsg.identity.core.aop;

/**
 * Created by Rahul Bhandwalkar on 3/31/2016.
 */
public class GenericModuleServiceAspect {
}
