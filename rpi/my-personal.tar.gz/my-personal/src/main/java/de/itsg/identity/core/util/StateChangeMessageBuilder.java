package de.itsg.identity.core.util;

import de.itsg.identity.common.model.Identity;
import de.itsg.messaging.message.StateChangeMessage;
import org.springframework.util.StringUtils;

/**
 * Created by Rahul Bhandwalkar on 3/31/2016.
 */
public class StateChangeMessageBuilder {

    public static StateChangeMessage getStateChangeMessage(Identity identity, String moduleName){
        if(StringUtils.isEmpty(moduleName))
            moduleName="BASIC_MODULE";
        StateChangeMessage msg = new StateChangeMessage(identity.getUuid(),identity.getEmail(),moduleName);
        msg.setModuleStatus(identity.getStatus().name());
        msg.setDoubleOptInStatus(identity.getDoubleOptInStatus().name());
        msg.setIdentity(identity);
        return msg;
    }
}
