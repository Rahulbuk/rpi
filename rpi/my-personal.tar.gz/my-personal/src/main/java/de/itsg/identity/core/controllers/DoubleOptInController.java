package de.itsg.identity.core.controllers;

import de.itsg.identity.common.model.EmailConfirmStatus;
import de.itsg.identity.common.services.DoubleOptInService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.web.bind.annotation.*;

/**
 * Created by Rahul Bhandwalkar on 3/29/2016.
 */

@RestController
@RequestMapping("/doubleOptIn/confirm")
@Slf4j
public class DoubleOptInController {
    @Autowired
    DoubleOptInService doubleOptInService;

    @Autowired
    private MessageSource messageSource;

    @RequestMapping(value = "/{uuid}/{token}", method = RequestMethod.POST)
    public EmailConfirmStatus confirmEmailAddress(@PathVariable String uuid, @PathVariable String token){
        log.debug("Email COnfirmatin Request Received");
       return doubleOptInService.confirmEmail(uuid,token);

    }

}
