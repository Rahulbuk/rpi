package de.itsg.identity.core.aop;

import de.itsg.identity.common.model.Identity;
import de.itsg.identity.core.util.StateChangeMessageBuilder;
import de.itsg.messaging.message.StateChangeMessage;
import de.itsg.messaging.sender.ITSGMsgSender;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Created by Rahul Bhandwalkar on 3/30/2016.
 */
@Aspect
@Component
public class BasicModuleServiceAspect {

    @Autowired
    private ITSGMsgSender sender;

    @AfterReturning(value = "execution(* de.itsg.identity.core.services.impl.BasicModuleServiceImpl.findOne(*)) " +
            "&& args(uuid)", returning = "identity")
    public void findOne(JoinPoint joinPoint, Long uuid, Identity identity){

    }

    @AfterReturning(value = "execution(* de.itsg.identity.core.services.impl.BasicModuleServiceImpl.save(*))",
            returning = "output")
    public void save(JoinPoint joinPoint, Identity output){
        StateChangeMessage message = StateChangeMessageBuilder.getStateChangeMessage(output,"BASIC_MODULE");
        sender.send(message);

    }

    @AfterReturning(value = "execution(* de.itsg.identity.core.services.impl.BasicModuleServiceImpl.update(*))",
            returning = "output")
    public void update(JoinPoint joinPoint, Identity output){
        StateChangeMessage message = StateChangeMessageBuilder.getStateChangeMessage(output,"BASIC_MODULE");
        sender.send(message);

    }


    @AfterReturning(value = "execution(* de.itsg.identity.core.services.impl.BasicModuleServiceImpl.delete(*))" +
            " && args(input)" )
    //TODO correct the delete call
    public void delete(JoinPoint joinPoint, Identity input){
        StateChangeMessage message = StateChangeMessageBuilder.getStateChangeMessage(input,"BASIC_MODULE");
        sender.send(message);
    }


    @AfterReturning(value = "execution(* de.itsg.identity.core.services.impl.BasicModuleServiceImpl.save(*))")
    public void findAll(JoinPoint joinPoint){

    }



}
