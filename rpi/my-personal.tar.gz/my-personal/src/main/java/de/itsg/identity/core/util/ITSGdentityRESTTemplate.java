package de.itsg.identity.core.util;

import lombok.extern.slf4j.Slf4j;
import org.apache.http.client.config.CookieSpecs;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.protocol.HttpContext;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpRequest;
import org.springframework.http.client.*;
import org.springframework.util.Base64Utils;
import org.springframework.util.ClassUtils;
import org.springframework.web.client.*;

import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.nio.charset.Charset;
import java.util.Collections;
import java.util.List;

/**
 * Created by nstanar on 15/02/16.
 */
@Slf4j
public class ITSGdentityRESTTemplate extends RestTemplate {

    private static final Charset UTF_8 = Charset.forName("UTF-8");


    public static URI appendLocalizationParameter(URI url) throws URISyntaxException {
        String appendQuery = "lang=" + LocaleContextHolder.getLocale().getLanguage();
        String newQuery = url.getQuery();

        if (newQuery == null) {
            newQuery = appendQuery;
        } else {
            newQuery += "&" + appendQuery;
        }

        return new URI(url.getScheme(), url.getAuthority(),
                url.getPath(), newQuery, url.getFragment());

    }

    public ITSGdentityRESTTemplate(ClientHttpRequestFactory requestFactory) {
        super(requestFactory);
    }

    public ITSGdentityRESTTemplate(String username, String password) {
        if (ClassUtils.isPresent("org.apache.http.client.config.RequestConfig", null)) {
            setRequestFactory(
                    new ITSGdentityRESTTemplate.CustomHttpComponentsClientHttpRequestFactory());
        }
        addAuthentication(username, password);
        setErrorHandler(new DefaultResponseErrorHandler() {
            @Override
            public void handleError(ClientHttpResponse response) throws IOException {
            }
        });

    }

    @Override
    protected <T> T doExecute(URI url, HttpMethod method, RequestCallback requestCallback, ResponseExtractor<T> responseExtractor) throws RestClientException {
        try {
            return super.doExecute(appendLocalizationParameter(url), method, requestCallback, responseExtractor);
        } catch (URISyntaxException e) {
            log.error("Exception occurred while trying to append localization parameter. ", e);
            e.printStackTrace();
        }
        return null;
    }


    protected static class CustomHttpComponentsClientHttpRequestFactory
            extends HttpComponentsClientHttpRequestFactory {

        private final String cookieSpec;

        private final boolean enableRedirects;

        public CustomHttpComponentsClientHttpRequestFactory() {
            this.cookieSpec =  CookieSpecs.IGNORE_COOKIES;
            this.enableRedirects = true;
        }

        @Override
        protected HttpContext createHttpContext(HttpMethod httpMethod, URI uri) {
            HttpClientContext context = HttpClientContext.create();
            context.setRequestConfig(getRequestConfig());
            return context;
        }

        protected RequestConfig getRequestConfig() {
            RequestConfig.Builder builder = RequestConfig.custom().setCookieSpec(this.cookieSpec)
                    .setAuthenticationEnabled(false)
                    .setRedirectsEnabled(this.enableRedirects);
            return builder.build();
        }

    }

    private void addAuthentication(String username, String password) {
        if (username == null) {
            return;
        }
        List<ClientHttpRequestInterceptor> interceptors = Collections
                .<ClientHttpRequestInterceptor>singletonList(
                        new ITSGdentityRESTTemplate.BasicAuthorizationInterceptor(username, password));
        setRequestFactory(new InterceptingClientHttpRequestFactory(getRequestFactory(),
                interceptors));
    }


    private static class BasicAuthorizationInterceptor
            implements ClientHttpRequestInterceptor {

        private final String username;

        private final String password;

        BasicAuthorizationInterceptor(String username, String password) {
            this.username = username;
            this.password = (password == null ? "" : password);
        }

        @Override
        public ClientHttpResponse intercept(HttpRequest request, byte[] body,
                                            ClientHttpRequestExecution execution) throws IOException {
            String token = Base64Utils.encodeToString(
                    (this.username + ":" + this.password).getBytes(UTF_8));
            request.getHeaders().add("Authorization", "Basic " + token);
            return execution.execute(request, body);
        }

    }

}
