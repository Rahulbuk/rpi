package de.itsg.identity.core.services.impl;

import de.itsg.identity.common.model.Identity;
import de.itsg.identity.common.services.BasicModuleService;
import de.itsg.identity.core.repositories.impl.BasicModuleRepositoryUserStoreImpl;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.HttpMethod;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.client.RestOperations;


/**
 * Created by nstanar on 14/12/15.
 */
@Service
@Transactional
@Slf4j
public class BasicModuleServiceImpl implements BasicModuleService {

   // @Autowired
   // private BasicModuleRepository basicModuleRepository;
   @Autowired
   @Qualifier("IdentityAPIRESTTemplate")
   private RestOperations restOperations;

    @Value("${itsg-ra.url}")
    private String raApiUrl;

    @Autowired
    private MessageSource messageSource;

    @Autowired
    BasicModuleRepositoryUserStoreImpl basicModuleRepositoryUserStore;


    public Identity save(Identity identity) {
        log.debug("Creating identity (basic module data) with email {}", identity.getEmail());
        if(null==identity.getUuid()) {
            identity.setUuid(getUUIDFromRa());
            return basicModuleRepositoryUserStore.saveIdentity(identity);
        }else {
            return basicModuleRepositoryUserStore.updateIdentity(identity);
        }

    }

    @Override
    @Transactional(readOnly = true)
    public Identity findOne(String uuid) {
        log.debug("Retrieving identity (basic module data) with uuid {}", uuid);
        Identity identity = basicModuleRepositoryUserStore.findOne(uuid);
        return identity;
    }

    @Override
    @Transactional(readOnly = true)
    public boolean exists(String uuid) {
        log.debug("Creating if identity (basic module data) exists for uuid {}", uuid);
        if (basicModuleRepositoryUserStore.findOne(uuid) == null) {
            return false;
        } else {
            return true;
        }

    }

    @Override
    @Transactional(readOnly = true)
    public Iterable<Identity> findAll() {
        log.debug("Retrieving all identities (basic module data for all users)");
        return basicModuleRepositoryUserStore.findAll();
    }

    @Override
    public Identity update(Identity identity) {
        log.debug("Updating identity (basic module data) with uuid {}", identity.getUuid());
        if (basicModuleRepositoryUserStore.findOne(identity.getUuid()) == null) {
            throw new IllegalArgumentException(messageSource.getMessage("resource.not.existing", null, LocaleContextHolder.getLocale()));
        }
        return basicModuleRepositoryUserStore.updateIdentity(identity);
    }

    @Override
    public void delete(String uuid) {
        log.debug("Updating identity (basic module data) with uuid {}", uuid);
        basicModuleRepositoryUserStore.delete(uuid);
    }

    @Override
    public Identity findByEmail(String email) {
        log.debug("Updating identity (basic module data) with uuid {}", email);
       return basicModuleRepositoryUserStore.findByEmail(email);
    }

    private String getUUIDFromRa(){
       return restOperations.exchange(raApiUrl+"/generateUUID", HttpMethod.GET,null, String.class).getBody();

    }
}
