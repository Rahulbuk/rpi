package de.itsg.identity.core.messaging;

/**
 * Created by Rahul Bhandwalkar on 3/31/2016.
 */
/*@Component
@Slf4j*/
public class DoubleOptInListener //extends DoubleOptInReceiver
{

    /*@Override
    @RabbitListener(bindings = @QueueBinding(
            value = @Queue(value = RabbitMQConfiguration.doubleoptInQueue, durable = "true"),
            exchange = @Exchange(value = RabbitMQConfiguration.doubleOptinExchange, type = "fanout",durable = "true")))

    public void processMessage(DoubleOptInMessage stateChangeMessage) {
         log.debug("Second Queue Receiving Message"+stateChangeMessage);
    }*/
}
