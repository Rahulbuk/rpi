package de.itsg.identity.security;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import javax.annotation.PostConstruct;

import org.springframework.core.io.Resource;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;



public class CustomeUserDetailsService implements UserDetailsService {

    private Resource usersPropertiesResource;

    private long usersFileLastModified;

    private InMemoryUserDetailsManager inMemoryUserDetailsManager;

    public CustomeUserDetailsService() {
    }

    public CustomeUserDetailsService(Resource usersPropertiesResource) {
        this.usersPropertiesResource = usersPropertiesResource;
    }

    synchronized void readOrRelaod() throws IOException {

        long lastModified;
        try {
            lastModified = usersPropertiesResource.lastModified();
            boolean needReload = (lastModified > this.usersFileLastModified);
            if (!needReload) {
                return;
            }
        } catch (IOException e) {
            throw new IOException("Error when trying to access users file " + usersPropertiesResource, e);
        }
        this.usersFileLastModified = lastModified;

        InputStream usersFileInputStream = null;
        try {
            usersFileInputStream = usersPropertiesResource.getInputStream();
            Properties usersProperties = new Properties();
            usersProperties.load(usersFileInputStream);
            this.inMemoryUserDetailsManager = new InMemoryUserDetailsManager(usersProperties);
        }
        catch (IOException e) {
            throw new IOException("I/O error when trying to load users file " + usersPropertiesResource, e);
        }

    }


    @Override
    public synchronized UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        try {
            readOrRelaod();
        } catch (IOException e) {
            e.printStackTrace();
            throw new  UsernameNotFoundException("User :"+username+ "not configured for this application");
        }
        return inMemoryUserDetailsManager.loadUserByUsername(username);
    }

    @PostConstruct
    public synchronized void init() throws IOException {

        if (usersPropertiesResource == null) {
            throw new IOException("'users' property must be set");
        }
        if (!usersPropertiesResource.exists()) {
            throw new IOException("The users file " + usersPropertiesResource + " does not exist");
        }

        readOrRelaod();
    }

    public void setProperties(Resource usersProperties) {
        this.usersPropertiesResource = usersProperties;
    }
}