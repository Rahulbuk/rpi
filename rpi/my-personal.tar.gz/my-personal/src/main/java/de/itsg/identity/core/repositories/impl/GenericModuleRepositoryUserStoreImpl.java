package de.itsg.identity.core.repositories.impl;


import com.itsg.userstore.CustomItsgUserStoreManager;
import de.itsg.identity.common.model.GenericModuleUser;
import de.itsg.identity.core.util.EntityAdapter;
import de.itsg.ra.common.model.AttributeDefinition;
import de.itsg.ra.common.model.RaModule;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import org.wso2.carbon.context.CarbonContext;
import org.wso2.carbon.user.api.UserStoreException;
import org.wso2.carbon.user.core.common.AbstractUserStoreManager;

import java.util.ArrayList;
import java.util.List;


@Component
public class GenericModuleRepositoryUserStoreImpl {

    @Autowired
    private CarbonContext corbonContext;

    @Autowired
    BasicModuleRepositoryUserStoreImpl basicModuleRepositoryUserStore;

    private CustomItsgUserStoreManager getUserStoreManager() {
        CustomItsgUserStoreManager customItsgUserStoreManager = null;
        try {
            AbstractUserStoreManager mgr = (AbstractUserStoreManager) corbonContext.getUserRealm().getUserStoreManager();
            customItsgUserStoreManager = (CustomItsgUserStoreManager) mgr.getSecondaryUserStoreManager();
        } catch (UserStoreException e) {
            e.printStackTrace();
            //TODO throw appropriate exception.
        }
        return customItsgUserStoreManager;
    }

    public GenericModuleUser saveGenericUser(RaModule module, GenericModuleUser genericModuleUser) throws UserStoreException {

        com.itsg.userstore.models.GenericModuleUser user = getUserStoreManager().doSaveUser(module.getName(),
                EntityAdapter.getGenericUserForUserStore(genericModuleUser),
                EntityAdapter.convertRAModule(module), true);
        GenericModuleUser retUser = EntityAdapter.getGenericUserEntity(user);
        retUser.setBasicIdentity(basicModuleRepositoryUserStore.findOne(user.getUuid()));
        return retUser;
    }


    public GenericModuleUser findUser(RaModule module, String identityUuid) {
        com.itsg.userstore.models.GenericModuleUser user= null;
        try {
            user = getUserStoreManager().findUser(module.getName(),identityUuid,EntityAdapter.getAttributeDefiniationList(module),true);
        } catch (org.wso2.carbon.user.core.UserStoreException e) {
            e.printStackTrace();
        }

        GenericModuleUser genUser =EntityAdapter.getGenericUserEntity(user);
        for(AttributeDefinition def:module.getAttributeDefinitions()){
            if(def.getIsLoginParam()){
                genUser.getQaAttributeSet().put(def.getName(),"");
            }
        }
        genUser.setBasicIdentity(basicModuleRepositoryUserStore.findOne(user.getUuid()));
        return  genUser;
    }

    public Iterable<GenericModuleUser> findAllUsers(RaModule module) {

        List<GenericModuleUser> retUserList = new ArrayList<>();
        try {
            List<com.itsg.userstore.models.GenericModuleUser> allGenericUsers= getUserStoreManager().findAllUsers(module.getName(),
                    EntityAdapter.getAttributeDefiniationList(module) ,true);
            for(com.itsg.userstore.models.GenericModuleUser genericUser:allGenericUsers){
                GenericModuleUser genUser = EntityAdapter.getGenericUserEntity(genericUser);
                for(AttributeDefinition def:module.getAttributeDefinitions()){
                    if(def.getIsLoginParam()){
                        genUser.getQaAttributeSet().put(def.getName(),"");
                    }
                }
                retUserList.add(genUser);
            }

        } catch (org.wso2.carbon.user.core.UserStoreException e) {
            e.printStackTrace();
            //TODO throw appropriate exception.
        }
        return retUserList;

    }

    public void deleteUser(String moduleName, String identityUuid) {
        try {
            getUserStoreManager().doDeleteUser(moduleName,identityUuid,true);
        } catch (org.wso2.carbon.user.core.UserStoreException e) {
            e.printStackTrace();
            //TODO throw appropriate exception.
        }
    }

    public GenericModuleUser updateUser(RaModule module, GenericModuleUser genericModuleUser) {

        com.itsg.userstore.models.GenericModuleUser user = null;
        try {
            user = getUserStoreManager().doUpdateUser(module.getName(),
                    EntityAdapter.getGenericUserForUserStore(genericModuleUser),
                    EntityAdapter.convertRAModule(module), true);
        } catch (org.wso2.carbon.user.core.UserStoreException e) {
            e.printStackTrace();
            //TODO throw appropriate exception.
        }
        GenericModuleUser genUser =EntityAdapter.getGenericUserEntity(user);
        for(AttributeDefinition def:module.getAttributeDefinitions()){
            if(def.getIsLoginParam()){
                genUser.getQaAttributeSet().put(def.getName(),"");
            }
        }
        genUser.setBasicIdentity(basicModuleRepositoryUserStore.findOne(user.getUuid()));
        return  genUser;
    }

    public Iterable<String> findAllUsersModuleList(String identityUuid) {
        List<String> moduleMap= new ArrayList<>();
        try {
            moduleMap = getUserStoreManager().findAllUsersModuleList(identityUuid);
        } catch (org.wso2.carbon.user.core.UserStoreException e) {
            e.printStackTrace();
            throw new IllegalArgumentException("");
            //TODO throw appropriate exception.
        }
        return moduleMap;
    }
}
