package de.itsg.identity.core.repositories.impl;

import com.itsg.userstore.CustomItsgUserStoreManager;
import com.itsg.userstore.models.GenericModuleUser;
import de.itsg.identity.common.model.Identity;
import de.itsg.identity.core.util.EntityAdapter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.wso2.carbon.context.CarbonContext;
import org.wso2.carbon.user.api.UserStoreException;
import org.wso2.carbon.user.core.common.AbstractUserStoreManager;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Rahul Bhandwalkar on 4/3/2016.
 */
@Component
public class BasicModuleRepositoryUserStoreImpl {

    @Autowired
    private CarbonContext corbonContext;//=CarbonContext.getThreadLocalCarbonContext();

    private static final String IDENTITY="IDENTITY";

    private CustomItsgUserStoreManager getUserStoreManager() {
        CustomItsgUserStoreManager customItsgUserStoreManager = null;
        try {
            AbstractUserStoreManager mgr = (AbstractUserStoreManager) corbonContext.getUserRealm().getUserStoreManager();
            customItsgUserStoreManager = (CustomItsgUserStoreManager) mgr.getSecondaryUserStoreManager();
        } catch (UserStoreException e) {
            e.printStackTrace();
            //TODO throw appropriate exception.
        }
        return customItsgUserStoreManager;
    }


    public Identity saveIdentity(Identity identity)  {

        GenericModuleUser user = null;
        try {
            user = getUserStoreManager().doSaveUser(IDENTITY, EntityAdapter.getGenericUserFromIdentity(identity), null,false);
        } catch (org.wso2.carbon.user.core.UserStoreException e) {
            e.printStackTrace();
            //TODO throw appropriate exception.
        }
        return EntityAdapter.getIdentityFromGenericUser(user);
    }


    public Identity updateIdentity(Identity identity)  {

        GenericModuleUser user = null;
        try {
            user = getUserStoreManager().doUpdateUser(IDENTITY, EntityAdapter.getGenericUserFromIdentity(identity),null, false);
        } catch (org.wso2.carbon.user.core.UserStoreException e) {
            e.printStackTrace();
            //TODO throw appropriate exception.
        }
        return EntityAdapter.getIdentityFromGenericUser(user);
    }

    public Identity findOne(String uuid) {
        GenericModuleUser user = null;
        Identity identity = new Identity();
        identity.setUuid(uuid);
        try {
            user = getUserStoreManager().findUser(IDENTITY, uuid, EntityAdapter.getEmptyIdentity() ,false);
        } catch (org.wso2.carbon.user.core.UserStoreException e) {
            e.printStackTrace();
            //TODO throw appropriate exception.
        }
        return EntityAdapter.getIdentityFromGenericUser(user);
    }

    public Iterable<Identity> findAll() {
        List<Identity> retUserList = new ArrayList<>();
        try {
            List<GenericModuleUser> allGenericUsers= getUserStoreManager().findAllUsers(IDENTITY, EntityAdapter.getEmptyIdentity() ,false);
            for(GenericModuleUser genericUser:allGenericUsers){
                retUserList.add(EntityAdapter.getIdentityFromGenericUser(genericUser));
            }

        } catch (org.wso2.carbon.user.core.UserStoreException e) {
            e.printStackTrace();
            return null;
            //TODO throw appropriate exception.
        }
        return retUserList;
    }

    public void delete(String uuid) {
        try {
            getUserStoreManager().doDeleteUser(IDENTITY,uuid,false);
        } catch (org.wso2.carbon.user.core.UserStoreException e) {
            e.printStackTrace();
            //TODO throw appropriate exception.
        }
    }

    public Identity findByEmail(String email) {

        GenericModuleUser user = null;
        Identity identity = new Identity();
        identity.setEmail(email);
        try {
            user = getUserStoreManager().findUserByEmail(email);
        } catch (org.wso2.carbon.user.core.UserStoreException e) {
            e.printStackTrace();
            return null;
            //TODO throw appropriate exception.
        }
        return EntityAdapter.getIdentityFromGenericUser(user);
    }
}
