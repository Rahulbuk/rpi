package de.itsg.identity;

import com.fasterxml.jackson.annotation.JsonInclude;
import de.itsg.identity.core.util.ITSGdentityRESTTemplate;
import de.itsg.identity.security.SecurityConfiguration;
import de.itsg.messaging.configuration.RabbitMQConfiguration;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.boot.context.web.SpringBootServletInitializer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Import;
import org.springframework.core.annotation.Order;
import org.springframework.core.env.Environment;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.http.converter.json.Jackson2ObjectMapperBuilder;
import org.springframework.jdbc.core.JdbcOperations;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jndi.JndiObjectFactoryBean;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.client.RestOperations;
import org.springframework.web.client.RestTemplate;
import org.wso2.carbon.context.CarbonContext;
import org.wso2.carbon.user.api.UserRealm;
import springfox.documentation.builders.ApiInfoBuilder;
import springfox.documentation.service.ApiInfo;
import springfox.documentation.spi.DocumentationType;
import springfox.documentation.spring.web.plugins.Docket;
import springfox.documentation.swagger2.annotations.EnableSwagger2;
//import org.wso2.carbon.context.CarbonContext;
//import org.wso2.carbon.user.api.UserRealm;

import javax.naming.NamingException;
import javax.sql.DataSource;
import java.util.Properties;

import static springfox.documentation.builders.PathSelectors.regex;

/**
 * Created by nstanar on 13/10/15.
 */

@SpringBootApplication
@EnableTransactionManagement
@EnableJpaRepositories
@EnableSwagger2
@Import({RabbitMQConfiguration.class})
@Order(1)
public class Application extends SpringBootServletInitializer {
    @Autowired
    RabbitMQConfiguration rabbitMQConfiguration;

    @Value("${itsg-messaging.queue}")
    private String messagingQueue;

    @Value("${itsg-ra.username}")
    private String raAPIUserName;

    @Value("${itsg-ra.password}")
    private String raAPIPassword;

  @Value("${itsg-identity.datasource.jndi-name}")
    private String itsgIdentityDatasourceJndiName;

    public static void main(String[] args) throws Exception {
        System.out.print("");
        SpringApplicationBuilder springApplication = (SpringApplicationBuilder) new SpringApplicationBuilder(Application.class).sources(Application.class).properties(getProperties()).run(args);
    }

    static Properties getProperties() {
        Properties props = new Properties();
        props.put("spring.config.location", "classpath:itsg-identity-api/,classpath:/app-info.properties,classpath:/vcs-git.properties");
        props.put("logging.config", "classpath:itsg-identity-api/logback.xml");
        return props;
    }

    @Override
    protected SpringApplicationBuilder configure(SpringApplicationBuilder application) {
        return application.sources(Application.class).properties(getProperties());
    }

    @Bean
    public Jackson2ObjectMapperBuilder jacksonBuilder() {
        Jackson2ObjectMapperBuilder b = new Jackson2ObjectMapperBuilder();
        b.failOnUnknownProperties(false);
        b.serializationInclusion(JsonInclude.Include.NON_NULL);
        return b;
    }

    @Bean(destroyMethod = "")
    public DataSource jndiDataSource() throws IllegalArgumentException, NamingException {
        JndiObjectFactoryBean bean = new JndiObjectFactoryBean();
        bean.setJndiName(itsgIdentityDatasourceJndiName);
      //  bean.setJndiName("itsgIdentityDataSource");// for IS server
        bean.setProxyInterface(DataSource.class);
        bean.setLookupOnStartup(false);
        bean.afterPropertiesSet();
        return (DataSource) bean.getObject();
    }

    @Autowired
    private JdbcOperations jdbcTemplate(DataSource dataSource) {
        return new JdbcTemplate(dataSource);
    }

    @Bean(name = "IdentityAPIRESTTemplate")
    public RestOperations restOperations() {
        return new ITSGdentityRESTTemplate(raAPIUserName, raAPIPassword);
    }

   @Bean
    public CarbonContext getContext(){
        return   CarbonContext.getThreadLocalCarbonContext();
    }

    @Bean
    public Docket newsApi() {
        return new Docket(DocumentationType.SWAGGER_2)
                .groupName("itsg-identity").apiInfo(apiInfo())
                .select()
                .paths(regex("(/RA.*|/basic-module.*|/doubleOptIn.*|/rpa.*|/users.*)"))
                .build();
    }

    private ApiInfo apiInfo() {
        return new ApiInfoBuilder()
                .title("IDENTITY API DOCUMENTION")
                .description("RA API documents")
                .version("2.0")
                .build();
    }
   /* @Bean
    public UserRealm getUserRealm(){

        UserRealm realm = getContext().getUserRealm();
        return  realm;
    }*/


   /* @Bean
    ITSGMsgReceiver receiver(){
        ITSGMsgReceiver receiver = new IdentityMessageReceiver() ;
        rabbitMQConfiguration.container().setMessageListener(receiver);
        return receiver;
    }*/

}
