package de.itsg.identity.core.repositories.rowmappers;

import de.itsg.identity.common.model.GenericModuleUser;
import de.itsg.ra.common.model.AttributeDefinition;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

/**
 * Created by nstanar on 18/01/16.
 */
public class GenericModuleRowMapper implements RowMapper<GenericModuleUser> {

    private static final String IDENTITY_UUID_COLUMN_LABEL = "identity_uuid";

    private static final String ID_COLUMN_LABEL = "id";

    private List<AttributeDefinition> attributes;

    public GenericModuleRowMapper(List<AttributeDefinition> attributes) {
        this.attributes = attributes;
    }

    @Override
    public GenericModuleUser mapRow(ResultSet resultSet, int i) throws SQLException {
        GenericModuleUser genericModule = new GenericModuleUser();
        genericModule.setUuid(resultSet.getString(IDENTITY_UUID_COLUMN_LABEL));
        genericModule.setId(resultSet.getLong(ID_COLUMN_LABEL));
        for (AttributeDefinition attribute : attributes) {
            genericModule.getQaAttributeSet().put(attribute.getName(), resultSet.getObject(attribute.getName()));
        }
        return genericModule;
    }
}
