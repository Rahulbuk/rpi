package de.itsg.identity.core.util;

import com.itsg.userstore.models.*;
import com.itsg.userstore.models.GenericModuleUser;
import de.itsg.identity.common.model.DoubleOptInStatus;
import de.itsg.identity.common.model.Identity;
import de.itsg.identity.common.model.Status;
import de.itsg.ra.common.model.AttributeDefinition;
import de.itsg.ra.common.model.RaModule;
import org.springframework.util.StringUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Created by Rahul Bhandwalkar on 4/2/2016.
 */
public class EntityAdapter {


    public static GenericModuleUser getGenericUserForUserStore(de.itsg.identity.common.model.GenericModuleUser user){

        GenericModuleUser retUser = new GenericModuleUser();
        retUser.setId(user.getId());
        retUser.setMessage(user.getMessage());
        if(!(user.getQaAttributeSet().containsKey("status")|| user.getQaAttributeSet().containsKey("STATUS"))){
            user.getQaAttributeSet().put("STATUS",Status.COMMITTED.name());
        }
        retUser.setQaAttributeSet(user.getQaAttributeSet());
        retUser.setUuid(user.getUuid());
        return  retUser;

    }

    public static de.itsg.identity.common.model.GenericModuleUser getGenericUserEntity(GenericModuleUser user){

        de.itsg.identity.common.model.GenericModuleUser retUser = new de.itsg.identity.common.model.GenericModuleUser();
        retUser.setId(user.getId());
        retUser.setMessage(user.getMessage());
        retUser.setQaAttributeSet(user.getQaAttributeSet());
        retUser.setBasicIdentity(getIdentityfromUserStoreIdentity(user.getIdentity()));
        retUser.setUuid(user.getUuid());
        return  retUser;

    }

    public static GenericModuleUser getGenericUserFromIdentity(Identity identity) {

        GenericModuleUser retUser = new GenericModuleUser();
        Map<String, Object> qualityAttributeSet= new HashMap<>();
        if(null!=identity.getUuid())
        retUser.setUuid(identity.getUuid());
        if(!StringUtils.isEmpty(identity.getEmail()))
        qualityAttributeSet.put("email",identity.getEmail());
        if(!StringUtils.isEmpty(identity.getFirstname()))
        qualityAttributeSet.put("firstname",identity.getFirstname());
        if(!StringUtils.isEmpty(identity.getLastname()))
        qualityAttributeSet.put("lastname",identity.getLastname());
        if(null!=identity.getNickname())
        qualityAttributeSet.put("nickname",identity.getNickname());
        if(!StringUtils.isEmpty(identity.getStatus()))
        qualityAttributeSet.put("status",identity.getStatus().name());
        if(!StringUtils.isEmpty(identity.getDoubleOptInStatus()))
        qualityAttributeSet.put("double_opt_in_status",identity.getDoubleOptInStatus().name());
        retUser.setQaAttributeSet(qualityAttributeSet);

        return  retUser;

    }


    public static Identity getIdentityFromGenericUser(GenericModuleUser user) {

        Identity identity = new Identity();
        identity.setUuid(user.getUuid());
        identity.setEmail((String)user.getQaAttributeSet().get("email"));
        identity.setFirstname((String)user.getQaAttributeSet().get("firstname"));
        identity.setLastname((String)user.getQaAttributeSet().get("lastname"));
        identity.setNickname((String)user.getQaAttributeSet().get("nickname"));
        if(org.apache.commons.lang.StringUtils.isNotEmpty((String)user.getQaAttributeSet().get("status")))
        identity.setStatus(Status.valueOf((String) user.getQaAttributeSet().get("status")));
        if(org.apache.commons.lang.StringUtils.isNotEmpty((String)user.getQaAttributeSet().get("double_opt_in_status")))
        identity.setDoubleOptInStatus(DoubleOptInStatus.valueOf((String)user.getQaAttributeSet().get("double_opt_in_status")));
        return  identity;

    }

    public static List<String> getEmptyIdentity() {

        List<String> params = new ArrayList<String>();
        params.add("uuid");
        params.add("email");
        params.add("firstname");
        params.add("lastname");
        params.add("nickname");
        params.add("status");
        params.add("double_opt_in_status");
        return params;
    }

    public static List<String> getAttributeDefiniationList(RaModule module) {
       List<AttributeDefinition> definitions=  module.getAttributeDefinitions();
       List<String> retList=new ArrayList<>();
        for(AttributeDefinition  def: definitions){
            retList.add(def.getName());
        }
        retList.add("status");
        retList.add("id");
        return retList;

    }

    public static UserStoreRaModule convertRAModule(RaModule module){
        UserStoreRaModule usModule = new UserStoreRaModule();
        usModule.setNamespace(module.getNamespace());
        usModule.setName(module.getName());
        usModule.setDisplayLabel(module.getDisplayLabel());
        usModule.setId(module.getId());
        usModule.setState(UserStoreRaModuleState.valueOf(module.getState().name()));
        usModule.setVersion(module.getVersion());
        List<AttributeDefinition> defs =module.getAttributeDefinitions();
        List<UserStoreAttributeDefinition> usDef = new ArrayList<>();
        for(AttributeDefinition def:defs){
            usDef.add(convertAttributeDefiniation(def));
        }

        usModule.setAttributeDefinitions(usDef);


        return usModule;
    }

    public static UserStoreAttributeDefinition convertAttributeDefiniation(AttributeDefinition definition){
        UserStoreAttributeDefinition retDef = new UserStoreAttributeDefinition();
        retDef.setName(definition.getName());
        retDef.setIsLoginParam(definition.getIsLoginParam());
        retDef.setAudience(definition.getAudience());
        retDef.setIsHeader(definition.getIsHeader());
        retDef.setOptional(definition.getOptional());
        retDef.setOptions(definition.getOptions());
        retDef.setType(UserStoreAttributeType.valueOf(definition.getType().name()));
        retDef.setUnique(definition.getUnique());
        return retDef;
    }

    public static Identity getIdentityfromUserStoreIdentity(UserStoreIdentity usIdentity){
        Identity identity = new Identity();
        identity.setUuid(usIdentity.getUuid());
        identity.setEmail(usIdentity.getEmail());
        identity.setFirstname(usIdentity.getFirstname());
        identity.setLastname(usIdentity.getLastname());
        identity.setNickname(usIdentity.getNickname());
        identity.setStatus(Status.valueOf(usIdentity.getStatus().name()));
        identity.setDoubleOptInStatus(DoubleOptInStatus.valueOf(usIdentity.getDoubleOptInStatus().name()));
        return identity;
    }
}
