package de.itsg.identity.core.controllers;

import com.fasterxml.jackson.annotation.JsonView;
import de.itsg.identity.common.model.GenericModuleUser;
import de.itsg.identity.common.services.GenericModuleService;
import de.itsg.ra.common.model.AttributeDefinition;
import de.itsg.ra.common.model.RaModule;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.i18n.LocaleContextHolder;
import org.springframework.http.HttpStatus;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.groups.Default;
import java.util.List;

/**
 * Created by nstanar on 18/01/16.
 */
@RestController
@RequestMapping(value = "RA")
@Slf4j
public class GenericModuleController {

    @Autowired
    private GenericModuleService genericModuleService;

    @Autowired
    private MessageSource messageSource;

    @RequestMapping(value = "/{moduleName}/users", method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.CREATED)
    @JsonView(GenericModuleUser.Insert.class)
    @PreAuthorize("hasPermission(#moduleName,'')")
    public GenericModuleUser saveUser(@PathVariable String moduleName, @RequestBody @Validated(GenericModuleUser.Insert.class) GenericModuleUser genericModuleUser) {
        log.debug("Creating data for ra module {} for user with uuid {}", genericModuleUser.getUuid());
        if (genericModuleUser.getQaAttributeSet().isEmpty()) {
            throw new IllegalArgumentException(messageSource.getMessage("create.data.missing", null, LocaleContextHolder.getLocale()));
        }
        return genericModuleService.saveUser(moduleName, genericModuleUser);
    }

    @RequestMapping(value = "/{moduleName}/users/{identityUuid}", method = RequestMethod.GET)
    @PreAuthorize("hasPermission(#moduleName,'')")
    public GenericModuleUser findUser(@PathVariable String moduleName, @PathVariable String identityUuid) {
        log.debug("Retrieving data from ra module {} for user with uuid {}", moduleName, identityUuid);
        return genericModuleService.findUser(moduleName, identityUuid);
    }

    @RequestMapping(value = "/{moduleName}/users", method = RequestMethod.GET)
    @PreAuthorize("hasPermission(#moduleName,'')")
    public Iterable<GenericModuleUser> findAllUsers(@PathVariable String moduleName) {
        log.debug("Retrieving data from ra module {} for all users");
        return genericModuleService.findAllUsers(moduleName);
    }

    @RequestMapping(value = "/{moduleName}/users/{identityUuid}", method = RequestMethod.DELETE)
    @PreAuthorize("hasPermission(#moduleName,'')")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteUser(@PathVariable String moduleName, @PathVariable String identityUuid) {
        log.debug("Deleting data from ra module {} for user with uuid {}", moduleName, identityUuid);
        genericModuleService.deleteUser(moduleName, identityUuid);
    }

    @RequestMapping(value = "/{moduleName}/users/{identityUuid}", method = RequestMethod.PUT)
    @PreAuthorize("hasPermission(#moduleName,'')")
    public GenericModuleUser updateUser(@PathVariable String moduleName, @PathVariable String identityUuid, @RequestBody @Validated(GenericModuleUser.Update.class) GenericModuleUser genericModule) {
        log.debug("Updating data for ra module {} for user with uuid {}", moduleName, identityUuid);
        if (genericModule.getQaAttributeSet().isEmpty()) {
            throw new IllegalArgumentException(messageSource.getMessage("update.data.missing", null, LocaleContextHolder.getLocale()));
        }
        if (!identityUuid.equals(genericModule.getUuid())) {
            throw new IllegalArgumentException(messageSource.getMessage("path.param.not.matching.request.entity", null, LocaleContextHolder.getLocale()));
        }
        return genericModuleService.updateUser(moduleName, genericModule);
    }

    @PreAuthorize("hasPermission(#moduleName,'')")
    @RequestMapping(value = "/{moduleName}" ,method = RequestMethod.DELETE)
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable String moduleName) {
        log.debug("Deleting ra module with name {}", moduleName);
        genericModuleService.delete(moduleName);
    }

    @RequestMapping(value = "/{moduleName}", method = RequestMethod.POST)
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void create(@RequestBody @Validated(RaModule.Insert.class) RaModule raModule) {
        log.debug("Creating ra module with name {}", raModule.getName());
        genericModuleService.create(raModule);
    }

    @RequestMapping(value = "/{moduleName}" ,method = RequestMethod.PUT)
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @PreAuthorize("hasPermission(#moduleName,'')")
    public void alter(@PathVariable String moduleName, @RequestBody @Validated({Default.class, AttributeDefinition.Insert.class}) List<AttributeDefinition> attributeDefinitions) {
        log.debug("Altering ra module with name {}", moduleName);
        genericModuleService.alter(moduleName, attributeDefinitions);
    }

}
