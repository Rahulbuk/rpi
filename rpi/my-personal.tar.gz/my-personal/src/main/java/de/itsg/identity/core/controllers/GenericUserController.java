package de.itsg.identity.core.controllers;

import de.itsg.identity.common.model.Identity;
import de.itsg.identity.common.services.BasicModuleService;
import de.itsg.identity.common.services.GenericModuleService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.*;

/**
 * Created by Rahul Bhandwalkar on 3/9/2016.
 */
@RestController
@RequestMapping("users")
@Slf4j
public class GenericUserController {
    @Autowired
    private GenericModuleService genericModuleService;

    @Autowired
    private BasicModuleService basicModuleService;


    @RequestMapping(value = "{identityUuid}",method = RequestMethod.GET)

    public Iterable<String> getUserWithModulesList(@PathVariable String identityUuid){
       return genericModuleService.findAllUsersModuleList(identityUuid);
    }

    @RequestMapping(value = "{identityUuid}/modules", method = RequestMethod.GET)
    @PreAuthorize("hasPermission('ADMIN','')") // default it will be validated against ADMIN ROLE
    public Map<String, Object> findAllUsers(@PathVariable String identityUuid) {
    Map<String, Object> ret = new HashMap<>();
       log.debug("Retrieving data from ra module {} for all users");
       Identity identity = basicModuleService.findOne(identityUuid);
       ret.put("basic-module",identity);
        Iterator<String> it =genericModuleService.findAllUsersModuleList(identityUuid).iterator();
       while (it.hasNext()){
           String module = it.next();
           ret.put(module ,genericModuleService.findUser(module,identityUuid));
       }
        return ret;
    }

}
