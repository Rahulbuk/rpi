package de.itsg.identity.core.aop;

import de.itsg.identity.common.model.DoubleOptInStatus;
import de.itsg.identity.common.model.EmailConfirmStatus;
import de.itsg.identity.common.model.Identity;
import de.itsg.identity.common.model.Status;
import de.itsg.identity.common.services.BasicModuleService;
import de.itsg.identity.core.util.StateChangeMessageBuilder;
import de.itsg.messaging.sender.ITSGMsgSender;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.AfterThrowing;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;


/**
 * Created by Rahul Bhandwalkar on 3/31/2016.
 */
@Aspect
@Component
public class DoubleOptInServiceAspect {

    @Autowired
    private ITSGMsgSender sender;
    @Autowired
    private BasicModuleService basicModuleService;

    @AfterReturning(value = "execution(* de.itsg.identity.core.services.impl.DoubleOptInServiceIml.sendEmail(*)) " +
            "&& args(identity)")
    public void sendMail(JoinPoint joinPoint, Identity identity){
        identity.setDoubleOptInStatus(DoubleOptInStatus.EMAIL_SENT);
        sender.send(StateChangeMessageBuilder.getStateChangeMessage(identity,"BASIC_MODULE"));
    }

    @AfterThrowing(value = "execution(* de.itsg.identity.core.services.impl.DoubleOptInServiceIml.sendEmail(*)) " +
            "&& args(identity)", throwing = "exp")
    public void sendMailError(JoinPoint joinPoint, Identity identity, Exception exp){
        identity.setDoubleOptInStatus(DoubleOptInStatus.EMAIL_REJECTED);
        sender.send(StateChangeMessageBuilder.getStateChangeMessage(identity,"BASIC_MODULE"));
    }


    @AfterReturning(value = "execution(* de.itsg.identity.core.services.impl.DoubleOptInServiceIml.confirmEmail(..)) " +
            "&& args(uuid, token)", returning = "ret")
    public void confirmEmail(JoinPoint joinPoint, String uuid, String token, EmailConfirmStatus ret){
        Identity identity = basicModuleService.findOne(uuid);
        if(EmailConfirmStatus.SUCCESSFUL.equals(ret)) {
            identity.setDoubleOptInStatus(DoubleOptInStatus.EMAIL_CONFIRMED);
            identity.setStatus(Status.PREREQUISITES_FULFILLED);
        }else {
            identity.setDoubleOptInStatus(DoubleOptInStatus.EMAIL_REJECTED);
        }
        sender.send(StateChangeMessageBuilder.getStateChangeMessage(identity,"BASIC_MODULE"));
    }

    @AfterThrowing(value = "execution(* de.itsg.identity.core.services.impl.DoubleOptInServiceIml.confirmEmail(*)) " +
            "&& args(identity)", throwing = "exp")
    public void confirmEmailError(JoinPoint joinPoint, Identity identity, Exception exp){
            identity.setDoubleOptInStatus(DoubleOptInStatus.EMAIL_REJECTED);
            identity.setStatus(Status.REJECTED);
        sender.send(StateChangeMessageBuilder.getStateChangeMessage(identity,"BASIC_MODULE"));
    }


}
